// Condom Section Code
$(document).ready(function () {


    $("#condom").click(function () {
        $("#condom-on-click").addClass('visible');
        $('#popup1').toggleClass('visible');
        $('#popup2').removeClass('visible');
        $('#popup3').removeClass('visible');
        $('#popup4').removeClass('visible');
        $("#prep-on-click").removeClass('visible');
        $("#abstinence-on-click").removeClass('visible');
        $("#testing-on-click").removeClass('visible');
        $('#click-on-icons-direction').addClass('hidden');
    });

    $("#condom-on-click").click(function () {
        $("#condom-on-click").removeClass('visible');
        $('#popup1').toggleClass('visible');
        $('#popup2').removeClass('visible');
        $('#popup3').removeClass('visible');
        $('#popup4').removeClass('visible');
        $('#click-on-icons-direction').removeClass('hidden');
    });

    $('#close-condom').click(function () {
        $("#popup1").toggleClass("visible");
        $("#condom-on-click").toggleClass("visible");
        $("#click-on-icons-direction").toggleClass("hidden");
    });

});

// Prep Section Code
$(document).ready(function () {

    $("#prep").click(function () {
        $("#prep-on-click").addClass('visible');
        $('#popup2').toggleClass('visible');
        $('#popup1').removeClass('visible');
        $('#popup3').removeClass('visible');
        $('#popup4').removeClass('visible');
        $("#condom-on-click").removeClass('visible');
        $("#abstinence-on-click").removeClass('visible');
        $("#testing-on-click").removeClass('visible');
        $('#click-on-icons-direction').addClass('hidden');
    });

    $("#prep-on-click").click(function () {
        $("#prep-on-click").removeClass('visible');
        $('#popup2').removeClass('visible');
        $('#popup1').removeClass('visible');
        $('#popup3').removeClass('visible');
        $('#popup4').removeClass('visible');
        $('#click-on-icons-direction').removeClass('hidden');
    });

    $('#close-prep').click(function () {
        $("#popup2").toggleClass("visible");
        $("#prep-on-click").toggleClass("visible");
        $("#click-on-icons-direction").toggleClass("hidden");
    });
});

// Abstinence Section Code
$(document).ready(function () {


    $("#abstinence").click(function () {
        $("#abstinence-on-click").addClass('visible');
        $('#popup3').toggleClass('visible');
        $('#popup1').removeClass('visible');
        $('#popup2').removeClass('visible');
        $('#popup4').removeClass('visible');
        $("#condom-on-click").removeClass('visible');
        $("#prep-on-click").removeClass('visible');
        $("#testing-on-click").removeClass('visible');
        $('#click-on-icons-direction').addClass('hidden');
    });

    $("#abstinence-on-click").click(function () {
        $("#abstinence-on-click").toggleClass('visible');
        $('#popup3').toggleClass('visible');
        $('#popup1').removeClass('visible');
        $('#popup2').removeClass('visible');
        $('#popup4').removeClass('visible');
        $('#click-on-icons-direction').removeClass('hidden');
    });

    $('#close-abstinence').click(function () {
        $("#popup3").toggleClass("visible");
        $("#abstinence-on-click").toggleClass("visible");
        $("#click-on-icons-direction").toggleClass("hidden");
    });
});

//Testing Section Code
$(document).ready(function () {

    $("#testing").click(function () {
        $("#testing-on-click").addClass('visible');
        $('#popup4').toggleClass('visible');
        $('#popup1').removeClass('visible');
        $('#popup2').removeClass('visible');
        $('#popup3').removeClass('visible');
        $("#condom-on-click").removeClass('visible');
        $("#prep-on-click").removeClass('visible');
        $("#abstinence-on-click").removeClass('visible');
        $('#click-on-icons-direction').addClass('hidden');
    });

    $("#testing-on-click").click(function () {
        $("#testing-on-click").toggleClass('visible');
        $('#popup4').toggleClass('visible');
        $('#popup1').removeClass('visible');
        $('#popup2').removeClass('visible');
        $('#popup3').removeClass('visible');
        $('#click-on-icons-direction').removeClass('hidden');
    });

    $('#close-testing').click(function () {
        $("#popup4").toggleClass("visible");
        $("#testing-on-click").toggleClass("visible");
        $("#click-on-icons-direction").toggleClass("hidden");
    });
});

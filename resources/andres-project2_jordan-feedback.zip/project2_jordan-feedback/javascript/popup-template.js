//************************ Templates ************************

// Button to open #popup1 modal
$(document).ready(function () {
    $('#condom').click(function () {
        $("#popup1").toggleClass("visible");
        $("#condom-on-click").toggleClass("visible");
        $("#click-on-icons-direction").toggleClass("hidden");
        
        });
});
// Button to close a #popup1 modal
$(document).ready(function () {
    $('#close-condom').click(function () {
        $("#popup1").toggleClass("visible");
        $("#condom-on-click").toggleClass("visible");
        $("#click-on-icons-direction").toggleClass("hidden");
        });
});
$(document).ready(function () {
    $('#condom-on-click').click(function () {
        $("#popup1").toggleClass("visible");
        $("#condom-on-click").toggleClass("visible");
        $("#click-on-icons-direction").toggleClass("hidden");
        });
});
    /*
$(document).ready(function () {
    $('#prep').click(function () {
        $("#popup1").toggleClass("visible");
        $("#condom-on-click").toggleClass("visible");
        });
});
$(document).ready(function () {
    $('#abstinence').click(function () {
        $("#popup1").toggleClass("visible");
        $("#condom-on-click").toggleClass("visible");
        });
});
$(document).ready(function () {
    $('#testing').click(function () {
        $("#popup1").toggleClass("visible");
        $("#condom-on-click").toggleClass("visible");
        });*/

// Button to open #popup2 modal
$(document).ready(function () {
    $('#prep').click(function () {
        $("#popup2").toggleClass("visible");
        $("#prep-on-click").toggleClass("visible");
        $("#click-on-icons-direction").toggleClass("hidden");
        });
});
// Button to close #popup2 modal
$(document).ready(function () {
    $('#close-prep').click(function () {
        $("#popup2").toggleClass("visible");
        $("#prep-on-click").toggleClass("visible");
        $("#click-on-icons-direction").toggleClass("hidden");
        });
});
$(document).ready(function () {
    $('#prep-on-click').click(function () {
        $("#popup2").toggleClass("visible");
        $("#prep-on-click").toggleClass("visible");
        $("#click-on-icons-direction").toggleClass("hidden");
        });
/*});
$(document).ready(function () {
    $('#condom').click(function () {
        $("#popup2").toggleClass("visible");
        $("#prep-on-click").toggleClass("visible");
        });
});
$(document).ready(function () {
    $('#abstinence').click(function () {
        $("#popup2").toggleClass("visible");
        $("#prep-on-click").toggleClass("visible");
        });
});
$(document).ready(function () {
    $('#testing').click(function () {
        $("#popup2").toggleClass("visible");
        $("#prep-on-click").toggleClass("visible");
        });*/
});
// Button to open #popup3 modal
$(document).ready(function () {
    $('#abstinence').click(function () {
        $("#popup3").toggleClass("visible");
        $("#abstinence-on-click").toggleClass("visible");
        $("#click-on-icons-direction").toggleClass("hidden");
        });
});
// Button to close #popup3 modal
$(document).ready(function () {
    $('#close-abstinence').click(function () {
        $("#popup3").toggleClass("visible");
        $("#abstinence-on-click").toggleClass("visible");
        $("#click-on-icons-direction").toggleClass("hidden");
        });
});
$(document).ready(function () {
    $('#abstinence-on-click').click(function () {
        $("#popup3").toggleClass("visible");
        $("#abstinence-on-click").toggleClass("visible");
        $("#click-on-icons-direction").toggleClass("hidden");
        });  
/*});
$(document).ready(function () {
    $('#condom').click(function () {
        $("#popup3").toggleClass("visible");
        $("#abstinence-on-click").toggleClass("visible");
        });
});
$(document).ready(function () {
    $('#prep').click(function () {
        $("#popup3").toggleClass("visible");
        $("#abstinence-on-click").toggleClass("visible");
        });
});
$(document).ready(function () {
    $('#testing').click(function () {
        $("#popup3").toggleClass("visible");
        $("#abstinence-on-click").toggleClass("visible");
        });*/
});
// Button to open #popup4 modal
$(document).ready(function () {
    $('#testing').click(function () {
        $("#popup4").toggleClass("visible");
        $("#testing-on-click").toggleClass("visible");
        $("#click-on-icons-direction").toggleClass("hidden");
        });
});
// Button to close #popup3 modal
$(document).ready(function () {
    $('#close-testing').click(function () {
        $("#popup4").toggleClass("visible");
        $("#testing-on-click").toggleClass("visible");
        $("#click-on-icons-direction").toggleClass("hidden");
        });
});
// Button to close #popup3 modal
$(document).ready(function () {
    $('#testing-on-click').click(function () {
        $("#popup4").toggleClass("visible");
        $("#testing-on-click").toggleClass("visible");
        $("#click-on-icons-direction").toggleClass("hidden");
        });  
/*});
$(document).ready(function () {
    $('#prep').click(function () {
        $("#popup4").toggleClass("visible");
        $("#testing-on-click").toggleClass("visible");
        });
});
$(document).ready(function () {
    $('#abstinence').click(function () {
        $("#popup4").toggleClass("visible");
        $("#testing-on-click").toggleClass("visible");
        });
});
$(document).ready(function () {
    $('#condom').click(function () {
        $("#popup4").toggleClass("visible");
        $("#testing-on-click").toggleClass("visible");
        });*/
});
// Button to open #scenario1-choice-popup modal
$(document).ready(function () {
    $('#scenario1-click-for-answer').click(function () {
        $("#scenario1-choice-popup").toggleClass("visible");
        $("#scenario1-click-for-answer").toggleClass("hidden");
        });
});
// Button to close #scenario1-choice-popup modal
$(document).ready(function () {
    $('#close-scenario1-explanation').click(function () {
        $("#scenario1-choice-popup").toggleClass("visible");
        $("#scenario1-click-for-answer").toggleClass("hidden");
        });
});
/*
// Button to open #scenario2-choice-popup modal
$(document).ready(function (){
    $('#scenario2-click-for-answer').click(function() {
        $("#scenario2-choice-popup").toggleClass("visible");
        });
});
// Button to close #scenario2-choice-popup modal
$(document).ready(function (){
    $('#close-scenario2-explanation').click(function() {
        $("#scenario2-choice-popup").toggleClass("visible")
        });*/
//Code for the scenario choose.
$(document).ready(function () {
    $('#condom2').click(function () {
        $("#condom-on-click-2").toggleClass("visible");
        });
});
$(document).ready(function () {
    $('#condom-on-click-2').click(function () {
        $("#condom-on-click-2").toggleClass("visible");
        });
});
$(document).ready(function () {
    $('#prep2').click(function () {
        $("#prep-on-click-2").toggleClass("visible");
        });
});
$(document).ready(function () {
    $('#prep-on-click-2').click(function () {
        $("#prep-on-click-2").toggleClass("visible");
        });
});
$(document).ready(function () {
    $('#abstinence2').click(function () {
        $("#abstinence-on-click-2").toggleClass("visible");
        });
});
$(document).ready(function () {
    $('#abstinence-on-click-2').click(function () {
        $("#abstinence-on-click-2").toggleClass("visible");
        });
});
$(document).ready(function () {
    $('#testing2').click(function () {
        $("#testing-on-click-2").toggleClass("visible");
        });
});
$(document).ready(function () {
    $('#testing-on-click-2').click(function () {
        $("#testing-on-click-2").toggleClass("visible");
        });
});
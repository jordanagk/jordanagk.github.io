$(document).ready(function (){
    $('#button1').click(function() {
        // ************ Changed the #letter-analysis to .letter-analysis because .letter-analysis is the name of the div that contains the #close-button and the paragraph about swashes.
        $(".letter-analysis").removeClass("invisible");
        $("#arrow").addClass("invisible");
        $("#large-letter-analysis").removeClass("invisible");
        $("#large-letter").addClass("invisible");
        $("#button1").addClass("invisible");
        });

});

$(document).ready(function (){
    //************* Changed from #button2 to #close-button because #close-button is the object that the user needs to interact with in order to close the analysis.
    $('#close-button').click(function() {
        // ************ Changed the #letter-analysis to .letter-analysis because .letter-analysis is the name of the div that contains the #close-button and the paragraph about swashes.
        $(".letter-analysis").addClass("invisible");
        $("#arrow").removeClass("invisible");
        $("#large-letter-analysis").addClass("invisible");
        $("#large-letter").removeClass("invisible");
        $("#button2").addClass("invisible");
        $("#button1").removeClass("invisible");
        });

});
